<h3>Hello!</h3>
<p>You got a new message from PayHelpa</p>
<div>
    {{$details}}
</div>lk
<p>Regards,<br>PayHelpa</p>
