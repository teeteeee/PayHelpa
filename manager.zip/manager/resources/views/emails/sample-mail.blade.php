@component('mail::message')

<h3>{{ $content['details']}}</h3><br>

@component('mail::button', ['url' => 'switfx.com'])
Login
@endcomponent


Thanks,<br>
{{ config('app.name') }}
@endcomponent
