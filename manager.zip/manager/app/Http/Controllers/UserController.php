<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Admin;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

use RealRashid\SweetAlert\Facades\Alert;
use App\Notifications\AccountVerificationEmail;
use App\Notifications\MessageSend;
use Illuminate\Support\Facades\Notification;
use Notifiable;
use Illuminate\Support\Facades\Mail;
use App\Mail\NewMessage;

class UserController extends Controller
{
   
 use \Illuminate\Notifications\Notifiable; 
 use \Illuminate\Notifications\RoutesNotifications;
 
    public function user(){
         $userss = DB::table('users')->get();
         return view('users', compact('userss'));
    }
     public static function GetUserName($user_id)
    {
        $user = User::where('user_id', $user_id)->select('name')->first();
        if($user != null)
        {
            echo $user->name;
        }
        else
        {
            echo "";
        }
        
    }
     public static function GetUser_ID($id)
    {
        // $userss = DB::table('users')->where('id', $id)->select('name')->get();
        $post = User::where('id', $id)->select('user_id')->first();
        
    }
    public function user_details($id){
         $userss = DB::table('users')->where('id',$id)->get();
         return view('user_details', compact('userss'));
    }
    
    public function message(Request $request, $user_id){
          $user = DB::table('users')
         ->select('email')
         ->where('user_id', $user_id)->first();
         $email = $user->email;
         return view('message',compact('email'));
    }
     public function messagesend(Request $request){
         $content = [
             "title"=>"New Message from PayHelpa",
             "details"=>$request->details
         ];
         Mail::to($request->email)->send(new NewMessage($content, $request));
         
       /* $data = array('details'=>$request->details);
            
        Mail::send('email/sample-mail', $content, function($message) use ($content, $request){
            $message->from ('test@switfx.com');
            $message->to($request->email);
            // $message->to('titi.adesola@gmail.com');
            $message->subject($content['details']);
        });*/
        
            //return $request->all();
        return redirect('ongoingstatus')->with('success','Message Sent!');
    }
    
    
    public function transactions(){
        $post = DB::table('transactions')
                /*->join('users', 'transactions.user', '=', 'users.id')*/
                ->select(/*'transactions.id','users.name', */'id','transaction_id', 'amount', /*'transactions.rate_type',*/ 'rate' /*'transactions.datee'*/)
                ->get();

        return view('transactions', compact('post'));
        
    }
    public function update_status($id){
        $post = DB::table('users')
                ->select('active_status')
                ->where('id', '=' ,$id )
                ->first();

                if ($post->active_status == 0) {
                     $status = 1;
                }
                else{
                     $status = 0;
                }
                $val = array('active_status' => $status); 
            DB::table('users')->where('id',$id)->update($val);
            return redirect('users');
    }
    public function selectuser(){
         return view('selectuser');
                         
     }

 public function localUsersStatus(){
        $post = DB::table('transactions')
        //->join('users', 'transactions.user', '=', 'users.id')
        ->select(/*'users.name',*/'id','rate','amount')
        ->where('transactions.status', 2)
        ->get();
        return view('localUsersStatus', compact('post'));
    }
     public function foreignUsersStatus(){
        $post = DB::table('transactions')
        ->join('users', 'transactions.user', '=', 'users.id')
        ->select(/*'users.name',*/'id','rate','amount')
        ->where('transactions.status', 2)
        ->orWhere('users.is_foreign_user', 1)
        ->get();
        return view('foreignUsersStatus', compact('post'));
    }
    /*public function status(){
        //$user= DB::table('users')
        
    }*/
    
     public function status(){
        $post = DB::table('transactions')
        ->where('transactions.status', 2)
         ->where('is_taken', 1)
        ->get();
        //return $post;
        return view('status', compact('post'));
    }
    
     public function successinfo($transaction_id){
       $post = DB::table('transactions')->where('transaction_id', $transaction_id)->get();
        return view('successinfo', compact('post'));
    }
    
    public function ongoingstatus(){
        $post = DB::table('transactions')
         ->where('transactions.status', 1)
        ->where('is_taken', 1)
        ->get();
        return view('ongoingstatus', compact('post'));
    }
    
    public function statusdeclined(){
        $post = DB::table('transactions')
        ->where('transactions.status', 0)
        ->where('is_taken', 0)
       //->orWhere('transactions.status', 2)
        ->get();
        return view('pendingstatus', compact('post'));
    }
     public function pendinginfo($transaction_id){
       $post = DB::table('transactions')->where('transaction_id', $transaction_id)->get();
        return view('pendinginfo', compact('post'));
    }
    public function verify(){
        $users = DB::table('users')->where('kyc_submitted', 1)->get();
        return view('verify', compact('users'));
    }
    public function update_verify($id){
         //$post = User::first();
        $post = DB::table('users')
                ->select('kyc_submitted')
                ->where('id', '=' ,$id )
                ->first();
                
                 $response = Http::withHeaders([
                    'X-Auth-Signature' => 'BE09BEE831CF262226B426E39BD1092AF84DC63076D4174FAC78A2261F9A3D6E59744983B8326B69CDF2963FE314DFC89635CFA37A40596508DD6EAAB09402C7',
                    'Client-Id' => 'dGVzdF9Qcm92aWR1cw=='
                ])->post('http://154.113.16.142:8088/appdevapi/api/PiPCreateDynamicAccountNumber', [
                    'account_name' => 'PayHelpa',
                ]);
                if ($response->status() == 200){
                    $response->update([
                        'reserved_account_number'=> $response->json('account_number')
                    ]);
                }else {
                    echo('Account number not generated');
                }


                if ($post->kyc_submitted == 0) {
                     $kyc_submitted = 1;
                }
                else{
                     $kyc_submitted = 0;
                }
                $val = array('kyc_submitted' => $kyc_submitted); 
            DB::table('users')->where('id',$id)->update($val);
           // $vermail =  DB::table('users')->where('id', '=', $id)->first();
           $vermail = User::find($id);
            $vermail->notify(new AccountVerificationEmail());
        
        return back()->with('success','User has been verifieddd!.');
           # return back();
            Alert::success('User has been verified');
            return redirect('verify')->with('success','User has been verified!');
           // Notification::send($users, new AccountVerificationEmail());
        //$users->notify(new AccountVerificationEmail());
        
        /*foreach ($users as $user) {
            $user->notify(new AccountVerificationEmail());
        }*/

    }
    
     
    public function show($id){
        $users = DB::table('users')->where('id',$id)->get();
        return view('show', compact('users'));
    }
}
