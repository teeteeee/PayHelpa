<?php echo e($slot); ?>

<?php /**PATH /home/switlzpt/public_html/manager/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>