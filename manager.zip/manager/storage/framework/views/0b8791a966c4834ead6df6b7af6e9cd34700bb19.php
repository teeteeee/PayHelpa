<?php echo e($slot); ?>

<?php /**PATH /home/switlzpt/payhelpa/manager/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>