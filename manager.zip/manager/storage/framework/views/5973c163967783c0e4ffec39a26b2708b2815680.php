<?php echo e($slot); ?>

<?php /**PATH /home/switlzpt/payhelpa/manager/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>