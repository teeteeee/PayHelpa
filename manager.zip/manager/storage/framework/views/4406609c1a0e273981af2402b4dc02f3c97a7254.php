<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'Laravel'): ?>

<img src="<?php echo e(asset('public/assets/img/logosmall.png')); ?>" alt="" class="logo">
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH /home/switlzpt/public_html/manager/resources/views/vendor/mail/html/header.blade.php ENDPATH**/ ?>