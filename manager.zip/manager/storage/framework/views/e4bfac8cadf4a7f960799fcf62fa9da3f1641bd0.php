<?php echo e($slot); ?>

<?php /**PATH /home/switlzpt/public_html/manager/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>