<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <!--<h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>-->
     <?php $__env->endSlot(); ?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from ventura.dreamguystech.com/template/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 12 Jul 2021 00:16:17 GMT -->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<title>PayHelpa - Dashboard</title>

<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('public/assets/img/favicon.png')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/bootstrap.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/font-awesome.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/feathericon.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('public/assets/plugins/morris/morris.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('public/assets/css/style.css')); ?>">
<!--[if lt IE 9]>
            <script src="<?php echo e(asset('public/assets/js/html5shiv.min.js')); ?>"></script>
            <script src="<?php echo e(asset('public/assets/js/respond.min.js')); ?>"></script>
        <![endif]-->
</head>
<body>


<div class="page-wrapper">
<div class="content container-fluid">

<div class="page-header">
<div class="row">
<div class="col">
<h3 class="page-title">Transactions </h3>
<ul class="breadcrumb">
<li class="breadcrumb-item"><a href="index">Dashboard</a></li>
<li class="breadcrumb-item active">Transactions</li>
</ul>
</div>

</div>
<div class="d-flex justify-content-center">
      <a href="#" class='btn btn-sm bg-warning-light mr-2'>International Transactions</a>
      <a href="#" class='btn btn-sm bg-warning-light mr-2'>Local Transactions</a>      
</div>
</div>
 
<div class="row">
<div class="col-sm-12">
<div class="card">
<div class="card-header">
<h4 class="card-title">List of Transactions</h4>
<!--<p class="card-text">
This is the most basic example of the datatables with zero configuration. Use the <code>.datatable</code> class to initialize datatables.
</p>-->
<div class="d-flex flex-row-reverse">
<form class="form-inline my-2 my-lg-0" action = "" method= "get" >
<div class="input-group">
  <div >
    <input type="search" class="form-control mr-sm-2" placeholder ="Search" name="keyword">
    <label class="form-label" for="form1"></label>
  </div>
  <input type="submit" class="btn btn-primary">
</div>
</form>
</div>
</div>
<div class="card-body">
<div class="table-responsive">
<table class="datatable table table-stripped">
<thead>
<tr>
<th>#</th>
<th>Name</th>
<th>Decription</th>
<th>Amount</th>
<th>Rate Type</th>
<th>Rate</th>
<th>Total</th>
<th>Date</th>
<th class="text-right">Action</th>
</tr>
</thead>

	<tbody>
	<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>		
		<td><?php echo e($key->t_id); ?></td>
		<td><?php echo e($key->name); ?></td>
		<td><?php echo e($key->description); ?></td>
		<td>$<?php echo e(number_format($key->amt)); ?>.00</td>
		<td>
			<?php if($key->rate_type == 1): ?>
			<p>Fixed rate<p>
			<?php else: ?>
			<p>My rate<p>
			<?php endif; ?>	

	</td>

		<td><?php echo e($key->rate); ?></td>
		<td>N<?php echo e(number_format($key->total)); ?>.00</td>
		<td><?php echo e(date("l, jS M, Y", strtotime ($key->datee))); ?></td>
		<td ></td>
		
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>


</table>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

</div>


<script src="<?php echo e(asset('public/assets/js/jquery-3.2.1.min.js')); ?>"></script>

<script src="<?php echo e(asset('public/assets/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/js/bootstrap.min.js')); ?>"></script>

<script src="<?php echo e(asset('public/assets/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>

<script src="<?php echo e(asset('public/assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/assets/plugins/datatables/datatables.min.js')); ?>"></script>

<script src="<?php echo e(asset('public/assets/js/script.js')); ?>"></script>
</body>
</html>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\Users\TeeTee Adesola\payhelpamanager2\resources\views/transactions.blade.php ENDPATH**/ ?>