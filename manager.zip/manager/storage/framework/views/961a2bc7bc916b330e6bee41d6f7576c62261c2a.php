<?php if($message = Session::get('success')): ?>
<div class="alert alert-success alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button>
    <strong>MESSAGE SENT! </strong>
</div>
<?php endif; ?>
<?php /**PATH /home/switlzpt/public_html/manager/resources/views/flash2-message.blade.php ENDPATH**/ ?>