<h3>Hello!</h3>
<p>You got a new message from PayHelpa</p>
<div>
    <?php echo e($details); ?>

</div>
<p>Regards,<br>PayHelpa</p>
<?php /**PATH /home/switlzpt/public_html/manager/resources/views/transactionmessage.blade.php ENDPATH**/ ?>